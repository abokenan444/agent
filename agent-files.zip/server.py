
import uvicorn
from fastapi import FastAPI
from pydantic import BaseModel
import subprocess, os

app = FastAPI()

class Command(BaseModel):
    cmd: str

@app.post("/run")
def run_command(c: Command):
    try:
        output = subprocess.check_output(c.cmd, shell=True, stderr=subprocess.STDOUT, text=True)
        return {"status":"ok", "output":output}
    except subprocess.CalledProcessError as e:
        return {"status":"error", "output":e.output}

if __name__ == "__main__":
    uvicorn.run("server:app", host="0.0.0.0", port=5001)
